<?php

$title="Planetory Information Page";

echo"<h1>";
echo $title;
echo "</h1>";

?>