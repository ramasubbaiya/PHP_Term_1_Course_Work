<?php
define("au","1.496");
$astronomical_unit=au;


define("pc","3.086");
$parsec=pc;


define("ly","9.463");
$light_year= ly;


define("Mo","1.99");
$solar_mass= Mo;

define("Ro","6.96");
$solar_radius=Ro;


define("Lo","3.9");
$solar_luminosity=Lo;


define("To","5.780");
$solar_temperature=To;


?>