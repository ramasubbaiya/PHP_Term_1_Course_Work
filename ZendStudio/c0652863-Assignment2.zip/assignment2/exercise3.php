<?php
$planets = array(
    'Mercury',
    'Venus',
    'Earth',
    'Mars',
    'jupiter',
    'Saturn',
    'Uranus',
    'Neptune',
    'Pluto'
);
foreach ($planets as $k=> $v)
    echo "$v<br>";

?>
