<form action='add_note.php' method='post'>
    <input type='text' name='username' placeholder='Username'>
    <input type='text' name='note' placeholder='Note'>
    <input type='submit' value='Add Note'>
</form>

<p><a href='index.php?do=clear'>Clear Session</a></p>
