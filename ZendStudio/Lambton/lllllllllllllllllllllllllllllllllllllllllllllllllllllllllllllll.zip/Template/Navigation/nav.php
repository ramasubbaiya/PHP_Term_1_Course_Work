<ul class='menu'>
    <li><a href='index.php?page=home'>Home</a></li>
    <li><a href='index.php?page=notes'>Notes</a></li>
    <li><a href='index.php?page=aboutus'>About</a></li>
</ul>