
                			
<header>
	<div class="menu_block ">
		<div class="container_12">
			<div class="grid_12">
				<nav class="horizontal-nav full-width horizontalNav-notprocessed">
					<ul class="sf-menu">
						<li class="<?php if($_GET['page']==home) echo"current";?>"><a href="index.php?page=home">Home</a></li>
						<li class="<?php if($_GET['page']==signup) echo"current";?>"><a href="index.php?page=signup">Sign In/Sign Up</a></li>
						<li class="<?php if($_GET['page']==quickbook) echo"current";?>"><a href="index.php?page=quickbook">Quick Book</a></li>
						<li class="<?php if($_GET['page']==listofcars) echo"current";?>"><a href="index.php?page=listofcars">Cars Available</a></li>
						<li class="<?php if($_GET['page']==webforum) echo"current";?>"><a href="index.php?page=webforum">Web Forum</a></li>
						<li class="<?php if($_GET['page']==contactus) echo"current";?>"><a href="index.php?page=contactus">ContactUs</a></li>
						<li class="<?php if($_GET['page']==logout) echo"current";?>"><a href="index.php?page=logout">LOGOUT</a></li>
					</ul>
				</nav>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="container_12">
		<div class="grid_12">
			<h1>
				<a href="index.php?page=home"> <img src="images/logo.png"
					alt="iRent Cars Company">
				</a>
			</h1>
		</div>
	</div>
	<div class="clear"></div>

</header>


		
			