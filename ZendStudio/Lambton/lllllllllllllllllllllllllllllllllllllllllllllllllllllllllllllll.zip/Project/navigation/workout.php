<?php
$r = gd_info();

print_r($r);