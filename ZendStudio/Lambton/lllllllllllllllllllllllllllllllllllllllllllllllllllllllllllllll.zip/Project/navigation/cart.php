

<div class="content">
	<div class="ic">Website</div>
	<div class="container_12">
		<div class="grid_12">
			<h3>Economy</h3>
		</div>
		<div class="clear"></div>
		<div class="gallery">
			<div class="grid_4">
				<img src="<?php echo$_GET['image']; ?>" alt="">
			</div>
			<div class="grid_12">
				<h3>Description</h3>
				<p>Looking for a luxury car without the luxury price? You've found the right car. This car is in great condition! This 2005 Cadillac CTS 3.6L has just under 71K gentle miles. I am the second owner, and have the maintenance logs from the previous owner. This car has been constantly serviced at Cadillac dealerships and is up to date on scheduled maintenance.

There are still 10 Months/10,000 Miles of warranty left. This warranty isn't a simple power train warranty; it covers pretty much anything mechanical and electrical. This warranty will be transferred with the vehicle unless you prefer not to, and the difference can be deducted from the actual sales price.

This car is very well maintained, both inside and out. I frequently wash and wax the exterior, polish the chrome wheels, clean the tires, wash under the hood, and ensure oil changes and maintenance repairs are done promptly.</p>
			</div>
			<div class="grid_12">
				<a href="index.php?page=bank"><p id="psubheading">Rent Now</a>
				</p>
			</div>
			<div class="grid_12">
				<!-- <a href=""><p id="psubheading">Like(<?php echo "hi"; ?>)</a>  -->
				</p>
			</div>
		</div>
	</div>
</div>
<div class="clear"></div>
<div class="grid_6 prefix_1">
	<a href="index.php?page=listofcars"><p id="psubheading">Go Back</p></a>
</div>
<div class="clear"></div>






