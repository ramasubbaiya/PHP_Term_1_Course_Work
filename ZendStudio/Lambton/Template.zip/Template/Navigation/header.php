<!DOCTYPE html>
<html>
    <head>
        <title><?php echo iRent ?></title>
        <link rel='stylesheet' href='styles.css' type='text/css'>
    </head>
    <body>
   </html>