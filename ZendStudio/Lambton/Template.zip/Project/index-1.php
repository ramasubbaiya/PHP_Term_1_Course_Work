<!DOCTYPE html>
<html lang="en">
	<head>
		<title>About</title>
		<meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
		<link rel="icon" href="images/favicon.ico">
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="stylesheet" href="css/style.css">
		<script src="js/jquery.js"></script>
		<script src="js/jquery-migrate-1.2.1.js"></script>
		<script src="js/script.js"></script>
		<script src="js/superfish.js"></script>
		<script src="js/jquery.ui.totop.js"></script>
		<script src="js/jquery.equalheights.js"></script>
		<script src="js/jquery.mobilemenu.js"></script>
		<script src="js/jquery.easing.1.3.js"></script>
		<script>
			$(document).ready(function(){
				$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>
		<!--[if lt IE 8]>
			<div style=' clear: both; text-align:center; position: relative;'>
				<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
					<img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
				</a>
			</div>
		<![endif]-->
		<!--[if lt IE 9]>
			<script src="js/html5shiv.js"></script>
			<link rel="stylesheet" media="screen" href="css/ie.css">
		<![endif]-->
	</head>
	<body class="" id="top">
		<div class="main">
<!--==============================header=================================-->
			<header>
				<div class="menu_block">
					<div class="container_12">
						<div class="grid_12">
							<nav class="horizontal-nav full-width horizontalNav-notprocessed">
								<ul class="sf-menu">
									<li><a href="index.html">Home</a></li>
									<li class="current"><a href="index-1.html">About</a></li>
									<li><a href="index-2.html">Cars</a></li>
									<li><a href="index-3.html">Services</a></li>
									<li><a href="index-4.html">Contacts</a></li>
								</ul>
							</nav>
							<div class="clear"></div>
						</div>
						<div class="clear"></div>
					</div>
				</div>
				<div class="container_12">
					<div class="grid_12">
						<h1>
							<a href="index.html">
								<img src="images/logo.png" alt="Your Happy Family">
							</a>
						</h1>
					</div>
				</div>
				<div class="clear"></div>
			</header>
<!--==============================Content=================================-->
			<div class="content"><div class="ic">More Website Templates @ TemplateMonster.com - April 07, 2014!</div>
				<div class="container_12">
					<div class="grid_7">
						<h3>A Few Words About Us</h3>
						<img src="images/page2_img1.jpg" alt="" class="img_inner fleft">
						<div class="extra_wrapper">
							<div class="text1 color2">
								<a href="#">Lorem ipsum dolor sit amet, consecteturpiscinger elit. </a>
							</div>
							<p>Want to know more about the free theme produced by TemplateMonster? Click this <span class="color1"><a href="http://blog.templatemonster.com/free-website-templates/" rel="dofollow">link</a></span>.</p>
							One theme is not enough for you to make a choice? Browse the vast variety of <span class="color1"><a href="http://www.templatemonster.com/properties/topic/society-people/" rel="nofollow">car templates</a></span> at TemplateMonster’s website.
						</div>
						<div class="clear cl1"></div>
						<p>Cras er te facilisis, nulla vel viver auctor, leo magna sodales felis, quis malesuad nibh odio ut veliter loki molo. Vivamus at magna non nunc tristique rhoncus. Aliquam nibh ante, egestas id dictum atermolok commodo luctus erito libero.</p>
						Praesent faucibus malesuada faucibus. Donec laoreet metus id laoreet malesuada. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam consectetur orci sed nulla facilisis consequatertolomon.
						Curabitur vel lorem sit amet nulla ullamcorper fermentum.
					</div>
					<div class="grid_4 prefix_1">
						<h3>Why Choose Us</h3>
						<ul class="list li">
							<li class="list_count">1</li>
							<li class="extra_wrapper">
								<div class="text1 color2"><a href="#">Econsecteturpiscinger elit</a></div>
								Sit meter ultricies erat rutrum. Cras er te facilisis, nulla vel viver auctor, leo magna sodales felis, quis malesuad nibh odio ut
							</li>
						</ul>
						<ul class="list li">
							<li class="list_count">2</li>
							<li class="extra_wrapper">
								<div class="text1 color2"><a href="#">Fconsecteturpiscingerelite</a></div>
								Git meter ultricies erat rutrum. Cras er te facilisis, nulla vel viver auctor, leo magna sodales felis, quis malesuad nibh odio
							</li>
						</ul>
						<ul class="list li">
							<li class="list_count">3</li>
							<li class="extra_wrapper">
								<div class="text1 color2"><a href="#">Hconsecteturpiscingeliter</a></div>
								Hit meter ultricies erat rutrum. Cras er te facilisis, nulla vel viver auctor, leo magna sodales felis, quis malesuad nibut velit.
							</li>
						</ul>
						<ul class="list li">
							<li class="list_count">4</li>
							<li class="extra_wrapper">
								<div class="text1 color2"><a href="#">Mconsecteturpiscinr elitwert</a></div>
								Kit meter ultricies erat rutrum. Cras er te facilisis, nulla vel viver auctor, leo magna sodales felis, quis malesuabh odio uter
							</li>
						</ul>
					</div>
					<div class="clear"></div>
					<div class="grid_12">
						<h3 class="h3__ind1">Testimonials</h3>
					</div>
					<div class="grid_4">
						<blockquote class="bq1">
							<p><i>Lorem ipsum dolor sit amet, consectetur adipiscinger elit. In mollis erat mattis neque facilisis, sit ameter ultricies erat rutrum. Cras facilisis, nulla vel viver auctor, leo magna... </i></p>
							<div class="color2">Tim Barkley</div>
						</blockquote>
					</div>
					<div class="grid_4">
						<blockquote class="bq1">
							<p><i>Dorem ipsum dolor sit amet, consectetur adipiscinger elit. In mollis erat mattis neque facilisis, sit ameter ultricies erat rutrum. Cras facilisis, nulla vel viver auctor, leo magwe... </i></p>
							<div class="color2">Linda Grey</div>
						</blockquote>
					</div>
					<div class="grid_4">
						<blockquote class="bq1">
							<p><i>Gorem ipsum dolor sit amet, consectetur adipiscinger elit. In mollis erat mattis neque facilisis, sit ameter ultricies erat rutrum. Cras facilisis, nulla vel viver auctoro magndales...</i></p>
							<div class="color2">Ann Pool</div>
						</blockquote>
					</div>
					<div class="clear"></div>
				</div>
			</div>
		</div>
<!--==============================footer=================================-->
		<footer>
			<div class="container_12">
				<div class="grid_12">
					<div class="f_phone"><span>Call Us:</span> + 1800 559 6580</div>
					<div class="socials">
						<a href="#" class="fa fa-twitter"></a>
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-google-plus"></a>
					</div>
					<div class="copy">
						<div class="st1">
						<div class="brand">Tour<span class="color1">T</span>axi </div>
						&copy; 2014	| <a href="#">Privacy Policy</a> </div> Website designed by <a href="http://www.templatemonster.com/" rel="nofollow">TemplateMonster.com</a>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</footer>
	</body>
</html>