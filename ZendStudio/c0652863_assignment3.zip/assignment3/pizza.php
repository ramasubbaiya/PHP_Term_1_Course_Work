<?php
$places = array(
    array(
        "name" => "Giresi's Pizza",
        "phone" => "519-336-1415",
        "url" => "http://www.giresispizza.com"
    ),
    array(
        "name" => "Firenze's Pizza",
        "phone" => "519-337-7546",
        "url" => "http://www.firenzespizza.com"
    ),
    array(
        "name" => "Kenny's Pizza",
        "phone" => "519-344-1100",
        "url" => ""
    ),
    array(
        "name" => "Italia Pizza",
        "phone" => "519-332-0081",
        "url" => "http://www.italiapizza.ca"
    ),
    array(
        "name" => "Napoli Pizza",
        "phone" => "519-542-1491",
        "url" => "http://www.napolipizza.com"
    )
);

$toppings = array(
    "pepperoni",
    "ham",
    "bacon",
    "chicken",
    "ground beef",
    "italian sausage",
    "mushrooms",
    "extra cheese",
    "green olives",
    "black olives",
    "onions",
    "green peppers",
    "pineapple",
    "anchovies"
);

$sizes = array(
    "personal",
    "small",
    "medium",
    "large",
    "extra large"
);
