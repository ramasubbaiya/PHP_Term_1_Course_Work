<?php
$a=7%3;
echo $a.'<br />';
$b=0%3;
echo $b.'<br />';
$c=1%3;
echo $c;