<?php
$a=2*3+5;
$b=2*(3+5);
echo $a.'<br />';
echo $b;
?>