<?php
$name ='Ramasubbaiya Adaikkalam';
echo "Hello world \n<br />";
echo 'This is the message from '. $name;
?>