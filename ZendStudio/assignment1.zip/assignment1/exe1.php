<?php
$a=1;
$valueA=5;
$valueB=3;
if($valueA>$valueB)
{
    echo 'value A is greater than Value B <br/>';
    //Outputs the string, appends a html <br/> tag
    $valueA=$valueB;
    echo "Value A is not equal to: $valueB";//Outputs the string
}
?>
