<?php
something{// I am a parent
   {//I am a subroutine or child
        //some code
    }another something{// I am a subroutine, too
        //more code
   }
}
?>