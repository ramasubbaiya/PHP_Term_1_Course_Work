<?php
$a=2;
echo $a++ . '<br>';
echo --$a . '<br>';
echo $a . '<br>';
$a=4;
$b=2;
echo ++$a*($a++ + --$b);
?>